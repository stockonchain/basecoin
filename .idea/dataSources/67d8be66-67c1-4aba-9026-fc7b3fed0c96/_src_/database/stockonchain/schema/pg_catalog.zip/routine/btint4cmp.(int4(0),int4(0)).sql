create function btint4cmp(integer, integer) returns integer
LANGUAGE INTERNAL
AS $$
btint4cmp
$$;
