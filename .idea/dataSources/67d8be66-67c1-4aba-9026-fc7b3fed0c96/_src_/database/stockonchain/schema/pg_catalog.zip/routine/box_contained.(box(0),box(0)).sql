create function box_contained(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_contained
$$;
