create function box_overbelow(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_overbelow
$$;
