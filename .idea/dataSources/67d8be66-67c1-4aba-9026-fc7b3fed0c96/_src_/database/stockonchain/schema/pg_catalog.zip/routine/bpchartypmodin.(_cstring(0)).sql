create function bpchartypmodin(cstring[]) returns integer
LANGUAGE INTERNAL
AS $$
bpchartypmodin
$$;
