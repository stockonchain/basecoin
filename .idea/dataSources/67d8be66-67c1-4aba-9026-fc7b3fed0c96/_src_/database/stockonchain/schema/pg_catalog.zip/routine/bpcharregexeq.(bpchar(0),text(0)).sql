create function bpcharregexeq(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
textregexeq
$$;
