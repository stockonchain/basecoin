create function btint42cmp(integer, smallint) returns integer
LANGUAGE INTERNAL
AS $$
btint42cmp
$$;
