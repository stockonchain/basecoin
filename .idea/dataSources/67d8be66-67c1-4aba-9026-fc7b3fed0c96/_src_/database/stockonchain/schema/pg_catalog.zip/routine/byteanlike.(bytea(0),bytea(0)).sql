create function byteanlike(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteanlike
$$;
