create function acosd(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dacosd
$$;
