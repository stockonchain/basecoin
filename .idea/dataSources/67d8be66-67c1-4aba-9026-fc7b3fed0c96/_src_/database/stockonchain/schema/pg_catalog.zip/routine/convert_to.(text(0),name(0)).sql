create function convert_to(text, name) returns bytea
LANGUAGE INTERNAL
AS $$
pg_convert_to
$$;
