create function cash_mi(money, money) returns money
LANGUAGE INTERNAL
AS $$
cash_mi
$$;
