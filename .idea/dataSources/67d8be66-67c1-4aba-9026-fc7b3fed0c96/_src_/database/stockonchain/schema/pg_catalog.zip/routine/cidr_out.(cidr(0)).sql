create function cidr_out(cidr) returns cstring
LANGUAGE INTERNAL
AS $$
cidr_out
$$;
