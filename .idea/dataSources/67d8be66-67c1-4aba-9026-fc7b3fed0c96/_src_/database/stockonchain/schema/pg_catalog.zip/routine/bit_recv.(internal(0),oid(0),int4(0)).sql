create function bit_recv(internal, oid, integer) returns bit
LANGUAGE INTERNAL
AS $$
bit_recv
$$;
