create function byteacmp(bytea, bytea) returns integer
LANGUAGE INTERNAL
AS $$
byteacmp
$$;
