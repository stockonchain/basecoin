create function byteane(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteane
$$;
