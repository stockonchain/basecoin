create function bpcharicnlike(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
texticnlike
$$;
