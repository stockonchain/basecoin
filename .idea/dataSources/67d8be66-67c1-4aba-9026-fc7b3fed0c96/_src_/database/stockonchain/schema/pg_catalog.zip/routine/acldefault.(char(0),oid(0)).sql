create function acldefault("char", oid) returns aclitem[]
LANGUAGE INTERNAL
AS $$
acldefault_sql
$$;
