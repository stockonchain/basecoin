create function arraycontains(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
arraycontains
$$;
