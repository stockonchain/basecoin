create function cash_words(money) returns text
LANGUAGE INTERNAL
AS $$
cash_words
$$;
