create function aclitemin(cstring) returns aclitem
LANGUAGE INTERNAL
AS $$
aclitemin
$$;
