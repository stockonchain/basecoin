create function cash_mul_flt8(money, double precision) returns money
LANGUAGE INTERNAL
AS $$
cash_mul_flt8
$$;
