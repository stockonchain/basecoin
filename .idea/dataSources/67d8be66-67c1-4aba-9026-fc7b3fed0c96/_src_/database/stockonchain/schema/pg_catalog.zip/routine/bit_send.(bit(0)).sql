create function bit_send(bit) returns bytea
LANGUAGE INTERNAL
AS $$
bit_send
$$;
