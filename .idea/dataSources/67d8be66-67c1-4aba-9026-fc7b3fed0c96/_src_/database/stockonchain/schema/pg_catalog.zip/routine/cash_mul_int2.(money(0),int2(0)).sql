create function cash_mul_int2(money, smallint) returns money
LANGUAGE INTERNAL
AS $$
cash_mul_int2
$$;
