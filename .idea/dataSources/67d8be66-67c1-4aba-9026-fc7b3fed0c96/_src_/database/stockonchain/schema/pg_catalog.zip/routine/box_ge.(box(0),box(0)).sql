create function box_ge(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_ge
$$;
