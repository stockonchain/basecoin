create function box_distance(box, box) returns double precision
LANGUAGE INTERNAL
AS $$
box_distance
$$;
