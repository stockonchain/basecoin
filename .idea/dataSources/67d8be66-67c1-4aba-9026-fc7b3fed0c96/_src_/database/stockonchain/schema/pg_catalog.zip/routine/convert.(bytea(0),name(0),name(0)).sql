create function convert(bytea, name, name) returns bytea
LANGUAGE INTERNAL
AS $$
pg_convert
$$;
