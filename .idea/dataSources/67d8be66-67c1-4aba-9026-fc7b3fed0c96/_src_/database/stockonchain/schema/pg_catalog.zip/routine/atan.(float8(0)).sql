create function atan(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
datan
$$;
