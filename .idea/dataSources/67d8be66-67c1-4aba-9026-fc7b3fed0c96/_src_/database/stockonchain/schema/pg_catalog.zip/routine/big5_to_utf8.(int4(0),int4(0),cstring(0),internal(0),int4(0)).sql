create function big5_to_utf8(integer, integer, cstring, internal, integer) returns void
LANGUAGE C
AS $$
big5_to_utf8
$$;
