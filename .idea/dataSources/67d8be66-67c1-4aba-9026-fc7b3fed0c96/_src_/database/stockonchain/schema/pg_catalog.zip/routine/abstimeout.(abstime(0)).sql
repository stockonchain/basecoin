create function abstimeout(abstime) returns cstring
LANGUAGE INTERNAL
AS $$
abstimeout
$$;
