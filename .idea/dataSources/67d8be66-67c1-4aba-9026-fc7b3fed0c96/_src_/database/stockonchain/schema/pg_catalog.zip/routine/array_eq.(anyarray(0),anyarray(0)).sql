create function array_eq(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_eq
$$;
