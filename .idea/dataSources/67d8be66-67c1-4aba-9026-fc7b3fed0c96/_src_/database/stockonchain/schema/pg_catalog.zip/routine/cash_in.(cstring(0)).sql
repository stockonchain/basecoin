create function cash_in(cstring) returns money
LANGUAGE INTERNAL
AS $$
cash_in
$$;
