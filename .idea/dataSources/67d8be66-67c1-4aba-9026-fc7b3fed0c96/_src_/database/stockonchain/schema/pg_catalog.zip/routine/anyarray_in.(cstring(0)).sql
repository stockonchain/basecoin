create function anyarray_in(cstring) returns anyarray
LANGUAGE INTERNAL
AS $$
anyarray_in
$$;
