create function box_overlap(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_overlap
$$;
