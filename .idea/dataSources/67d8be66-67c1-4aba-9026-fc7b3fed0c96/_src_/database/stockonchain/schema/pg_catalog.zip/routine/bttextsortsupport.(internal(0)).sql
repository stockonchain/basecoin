create function bttextsortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
bttextsortsupport
$$;
