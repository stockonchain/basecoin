create function anyarray_recv(internal) returns anyarray
LANGUAGE INTERNAL
AS $$
anyarray_recv
$$;
