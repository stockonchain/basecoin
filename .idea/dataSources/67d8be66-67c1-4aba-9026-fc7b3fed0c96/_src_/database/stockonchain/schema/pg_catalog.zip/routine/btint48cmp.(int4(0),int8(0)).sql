create function btint48cmp(integer, bigint) returns integer
LANGUAGE INTERNAL
AS $$
btint48cmp
$$;
