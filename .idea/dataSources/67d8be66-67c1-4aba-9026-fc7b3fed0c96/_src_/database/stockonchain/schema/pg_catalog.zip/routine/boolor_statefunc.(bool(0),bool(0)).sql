create function boolor_statefunc(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boolor_statefunc
$$;
