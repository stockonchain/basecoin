create function array_smaller(anyarray, anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_smaller
$$;
