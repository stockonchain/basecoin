create function cbrt(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dcbrt
$$;
