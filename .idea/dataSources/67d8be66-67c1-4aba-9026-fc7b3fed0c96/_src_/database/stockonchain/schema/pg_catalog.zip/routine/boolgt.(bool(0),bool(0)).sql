create function boolgt(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boolgt
$$;
