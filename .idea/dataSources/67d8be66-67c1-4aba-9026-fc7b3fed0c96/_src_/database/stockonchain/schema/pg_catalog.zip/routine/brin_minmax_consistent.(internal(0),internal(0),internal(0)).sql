create function brin_minmax_consistent(internal, internal, internal) returns boolean
LANGUAGE INTERNAL
AS $$
brin_minmax_consistent
$$;
