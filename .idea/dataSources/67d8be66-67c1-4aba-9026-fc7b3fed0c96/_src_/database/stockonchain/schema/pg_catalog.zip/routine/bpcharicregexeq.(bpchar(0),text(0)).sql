create function bpcharicregexeq(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
texticregexeq
$$;
