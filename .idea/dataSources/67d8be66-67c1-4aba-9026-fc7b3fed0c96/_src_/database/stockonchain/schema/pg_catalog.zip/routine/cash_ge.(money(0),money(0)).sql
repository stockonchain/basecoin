create function cash_ge(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_ge
$$;
