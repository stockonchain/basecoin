create function circle_mul_pt(circle, point) returns circle
LANGUAGE INTERNAL
AS $$
circle_mul_pt
$$;
