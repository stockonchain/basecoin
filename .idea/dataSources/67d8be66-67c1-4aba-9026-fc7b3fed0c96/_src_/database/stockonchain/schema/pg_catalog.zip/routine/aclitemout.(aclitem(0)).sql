create function aclitemout(aclitem) returns cstring
LANGUAGE INTERNAL
AS $$
aclitemout
$$;
