create function abstimelt(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimelt
$$;
