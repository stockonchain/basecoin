create function bitcmp(bit, bit) returns integer
LANGUAGE INTERNAL
AS $$
bitcmp
$$;
