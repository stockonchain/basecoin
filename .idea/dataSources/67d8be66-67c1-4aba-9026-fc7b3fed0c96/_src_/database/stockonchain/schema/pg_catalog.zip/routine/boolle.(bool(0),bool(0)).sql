create function boolle(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boolle
$$;
