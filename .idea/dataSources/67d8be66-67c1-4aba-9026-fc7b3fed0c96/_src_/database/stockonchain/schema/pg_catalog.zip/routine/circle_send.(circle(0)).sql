create function circle_send(circle) returns bytea
LANGUAGE INTERNAL
AS $$
circle_send
$$;
