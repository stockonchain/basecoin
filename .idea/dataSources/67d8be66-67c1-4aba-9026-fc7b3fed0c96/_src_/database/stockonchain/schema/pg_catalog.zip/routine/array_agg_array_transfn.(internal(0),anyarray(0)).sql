create function array_agg_array_transfn(internal, anyarray) returns internal
LANGUAGE INTERNAL
AS $$
array_agg_array_transfn
$$;
