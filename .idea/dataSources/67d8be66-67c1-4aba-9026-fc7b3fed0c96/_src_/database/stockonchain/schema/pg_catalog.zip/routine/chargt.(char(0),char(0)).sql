create function chargt("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
chargt
$$;
