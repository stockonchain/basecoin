create function cidr_in(cstring) returns cidr
LANGUAGE INTERNAL
AS $$
cidr_in
$$;
