create function boolrecv(internal) returns boolean
LANGUAGE INTERNAL
AS $$
boolrecv
$$;
