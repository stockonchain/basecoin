create function circle_same(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_same
$$;
