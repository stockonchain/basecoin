create function char_length(text) returns integer
LANGUAGE INTERNAL
AS $$
textlen
$$;
