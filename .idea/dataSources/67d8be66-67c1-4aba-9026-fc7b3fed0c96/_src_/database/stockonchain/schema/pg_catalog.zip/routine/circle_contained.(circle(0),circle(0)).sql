create function circle_contained(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_contained
$$;
