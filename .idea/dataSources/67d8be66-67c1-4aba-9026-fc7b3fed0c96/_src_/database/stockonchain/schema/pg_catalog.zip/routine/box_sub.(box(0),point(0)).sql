create function box_sub(box, point) returns box
LANGUAGE INTERNAL
AS $$
box_sub
$$;
