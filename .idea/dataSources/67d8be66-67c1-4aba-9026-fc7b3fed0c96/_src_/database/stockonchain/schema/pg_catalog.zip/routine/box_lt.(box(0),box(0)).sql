create function box_lt(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_lt
$$;
