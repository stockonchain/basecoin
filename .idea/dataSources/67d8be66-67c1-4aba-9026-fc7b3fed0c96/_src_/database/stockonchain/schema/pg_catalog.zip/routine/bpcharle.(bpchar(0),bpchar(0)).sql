create function bpcharle(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpcharle
$$;
