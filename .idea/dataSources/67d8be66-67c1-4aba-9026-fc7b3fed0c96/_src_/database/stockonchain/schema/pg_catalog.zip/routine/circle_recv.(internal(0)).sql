create function circle_recv(internal) returns circle
LANGUAGE INTERNAL
AS $$
circle_recv
$$;
