create function circle_le(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_le
$$;
