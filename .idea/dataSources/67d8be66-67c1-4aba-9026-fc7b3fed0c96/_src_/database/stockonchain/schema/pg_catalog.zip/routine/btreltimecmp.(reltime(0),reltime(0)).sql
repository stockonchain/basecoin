create function btreltimecmp(reltime, reltime) returns integer
LANGUAGE INTERNAL
AS $$
btreltimecmp
$$;
