create function brin_summarize_new_values(regclass) returns integer
LANGUAGE INTERNAL
AS $$
brin_summarize_new_values
$$;
