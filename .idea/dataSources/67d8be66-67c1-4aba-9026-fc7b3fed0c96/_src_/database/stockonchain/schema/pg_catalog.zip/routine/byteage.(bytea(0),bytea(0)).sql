create function byteage(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteage
$$;
