create function btfloat4cmp(real, real) returns integer
LANGUAGE INTERNAL
AS $$
btfloat4cmp
$$;
