create function byteaeq(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteaeq
$$;
