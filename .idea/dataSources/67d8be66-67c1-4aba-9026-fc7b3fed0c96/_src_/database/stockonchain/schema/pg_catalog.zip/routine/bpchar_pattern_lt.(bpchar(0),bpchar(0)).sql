create function bpchar_pattern_lt(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpchar_pattern_lt
$$;
