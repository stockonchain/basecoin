create function bool_or(boolean) returns boolean
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
