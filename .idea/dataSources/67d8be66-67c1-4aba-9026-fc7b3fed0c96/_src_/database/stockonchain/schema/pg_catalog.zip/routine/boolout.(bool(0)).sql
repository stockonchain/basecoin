create function boolout(boolean) returns cstring
LANGUAGE INTERNAL
AS $$
boolout
$$;
