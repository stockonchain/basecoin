create function bttext_pattern_cmp(text, text) returns integer
LANGUAGE INTERNAL
AS $$
bttext_pattern_cmp
$$;
