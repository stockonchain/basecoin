create function aclremove(aclitem[], aclitem) returns aclitem[]
LANGUAGE INTERNAL
AS $$
aclremove
$$;
