create function bpchar_sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
bpchar_sortsupport
$$;
