create function atan2d(double precision, double precision) returns double precision
LANGUAGE INTERNAL
AS $$
datan2d
$$;
