create function box_le(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_le
$$;
