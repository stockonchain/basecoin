create function "RI_FKey_noaction_del"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_noaction_del
$$;
