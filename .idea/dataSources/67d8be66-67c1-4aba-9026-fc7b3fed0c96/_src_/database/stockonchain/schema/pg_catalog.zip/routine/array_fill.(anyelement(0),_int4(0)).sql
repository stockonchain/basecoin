create function array_fill(anyelement, integer[]) returns anyarray
LANGUAGE INTERNAL
AS $$
array_fill
$$;
