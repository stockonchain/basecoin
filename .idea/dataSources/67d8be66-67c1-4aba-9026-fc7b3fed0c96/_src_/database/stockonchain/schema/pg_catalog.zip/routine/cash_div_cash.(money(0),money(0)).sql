create function cash_div_cash(money, money) returns double precision
LANGUAGE INTERNAL
AS $$
cash_div_cash
$$;
