create function biteq(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
biteq
$$;
