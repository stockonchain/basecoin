create function circle_gt(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_gt
$$;
