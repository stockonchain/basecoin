create function asin(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dasin
$$;
