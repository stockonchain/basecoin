create function "RI_FKey_setdefault_upd"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_setdefault_upd
$$;
