create function bitgt(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
bitgt
$$;
