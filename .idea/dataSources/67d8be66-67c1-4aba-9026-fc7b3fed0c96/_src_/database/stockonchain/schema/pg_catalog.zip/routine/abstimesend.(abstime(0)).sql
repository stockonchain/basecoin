create function abstimesend(abstime) returns bytea
LANGUAGE INTERNAL
AS $$
abstimesend
$$;
