create function bitcat(bit varying, bit varying) returns bit varying
LANGUAGE INTERNAL
AS $$
bitcat
$$;
