create function char(integer) returns "char"
LANGUAGE INTERNAL
AS $$
i4tochar
$$;
