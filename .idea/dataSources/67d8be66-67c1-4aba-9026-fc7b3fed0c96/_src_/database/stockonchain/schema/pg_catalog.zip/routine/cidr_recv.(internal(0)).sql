create function cidr_recv(internal) returns cidr
LANGUAGE INTERNAL
AS $$
cidr_recv
$$;
