create function array_ge(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_ge
$$;
