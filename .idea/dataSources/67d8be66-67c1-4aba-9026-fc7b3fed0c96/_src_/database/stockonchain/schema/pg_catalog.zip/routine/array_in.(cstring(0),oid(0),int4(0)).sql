create function array_in(cstring, oid, integer) returns anyarray
LANGUAGE INTERNAL
AS $$
array_in
$$;
