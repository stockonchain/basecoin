create function box_eq(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_eq
$$;
