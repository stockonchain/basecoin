create function bttintervalcmp(tinterval, tinterval) returns integer
LANGUAGE INTERNAL
AS $$
bttintervalcmp
$$;
