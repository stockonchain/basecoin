create function booleq(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
booleq
$$;
