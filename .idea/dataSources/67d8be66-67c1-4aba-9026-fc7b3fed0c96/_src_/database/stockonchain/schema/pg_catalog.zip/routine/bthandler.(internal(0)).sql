create function bthandler(internal) returns index_am_handler
LANGUAGE INTERNAL
AS $$
bthandler
$$;
