create function btarraycmp(anyarray, anyarray) returns integer
LANGUAGE INTERNAL
AS $$
btarraycmp
$$;
