create function box_out(box) returns cstring
LANGUAGE INTERNAL
AS $$
box_out
$$;
