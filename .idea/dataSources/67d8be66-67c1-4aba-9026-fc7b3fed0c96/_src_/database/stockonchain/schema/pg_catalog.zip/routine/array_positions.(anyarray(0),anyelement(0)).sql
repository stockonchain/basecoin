create function array_positions(anyarray, anyelement) returns integer[]
LANGUAGE INTERNAL
AS $$
array_positions
$$;
