create function circle_ge(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_ge
$$;
