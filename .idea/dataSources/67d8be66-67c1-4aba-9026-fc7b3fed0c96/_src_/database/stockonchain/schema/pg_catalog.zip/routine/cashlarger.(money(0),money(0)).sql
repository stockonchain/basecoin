create function cashlarger(money, money) returns money
LANGUAGE INTERNAL
AS $$
cashlarger
$$;
