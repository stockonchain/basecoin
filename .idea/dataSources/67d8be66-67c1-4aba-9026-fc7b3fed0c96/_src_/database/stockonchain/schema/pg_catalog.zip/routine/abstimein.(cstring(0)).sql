create function abstimein(cstring) returns abstime
LANGUAGE INTERNAL
AS $$
abstimein
$$;
