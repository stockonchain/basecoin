create function boolsend(boolean) returns bytea
LANGUAGE INTERNAL
AS $$
boolsend
$$;
