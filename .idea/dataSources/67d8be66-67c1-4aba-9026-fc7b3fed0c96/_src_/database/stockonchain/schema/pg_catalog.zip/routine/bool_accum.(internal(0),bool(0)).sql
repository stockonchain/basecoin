create function bool_accum(internal, boolean) returns internal
LANGUAGE INTERNAL
AS $$
bool_accum
$$;
