create function charle("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
charle
$$;
