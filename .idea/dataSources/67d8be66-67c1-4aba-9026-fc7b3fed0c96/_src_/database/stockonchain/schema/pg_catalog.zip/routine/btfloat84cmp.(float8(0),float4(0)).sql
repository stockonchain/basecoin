create function btfloat84cmp(double precision, real) returns integer
LANGUAGE INTERNAL
AS $$
btfloat84cmp
$$;
