create function cos(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dcos
$$;
