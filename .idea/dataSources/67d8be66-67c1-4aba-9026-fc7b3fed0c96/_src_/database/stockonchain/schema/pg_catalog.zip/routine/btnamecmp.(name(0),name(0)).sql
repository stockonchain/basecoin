create function btnamecmp(name, name) returns integer
LANGUAGE INTERNAL
AS $$
btnamecmp
$$;
