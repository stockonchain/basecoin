create function bytealike(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
bytealike
$$;
