create function abbrev(cidr) returns text
LANGUAGE INTERNAL
AS $$
cidr_abbrev
$$;
