create function bool_alltrue(internal) returns boolean
LANGUAGE INTERNAL
AS $$
bool_alltrue
$$;
