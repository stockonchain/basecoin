create function charlt("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
charlt
$$;
