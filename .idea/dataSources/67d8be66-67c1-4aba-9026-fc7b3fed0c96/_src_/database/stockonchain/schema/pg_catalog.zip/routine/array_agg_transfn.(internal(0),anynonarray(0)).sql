create function array_agg_transfn(internal, anynonarray) returns internal
LANGUAGE INTERNAL
AS $$
array_agg_transfn
$$;
