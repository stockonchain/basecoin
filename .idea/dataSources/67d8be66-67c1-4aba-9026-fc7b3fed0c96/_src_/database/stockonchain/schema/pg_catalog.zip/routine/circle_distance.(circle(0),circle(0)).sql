create function circle_distance(circle, circle) returns double precision
LANGUAGE INTERNAL
AS $$
circle_distance
$$;
