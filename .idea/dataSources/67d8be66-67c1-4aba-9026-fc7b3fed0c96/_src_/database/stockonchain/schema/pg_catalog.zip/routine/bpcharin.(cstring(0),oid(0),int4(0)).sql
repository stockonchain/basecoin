create function bpcharin(cstring, oid, integer) returns character
LANGUAGE INTERNAL
AS $$
bpcharin
$$;
