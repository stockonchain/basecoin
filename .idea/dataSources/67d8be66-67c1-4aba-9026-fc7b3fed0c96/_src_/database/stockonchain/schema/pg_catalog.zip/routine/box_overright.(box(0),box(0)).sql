create function box_overright(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_overright
$$;
