create function cideq(cid, cid) returns boolean
LANGUAGE INTERNAL
AS $$
cideq
$$;
