create function array_le(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_le
$$;
