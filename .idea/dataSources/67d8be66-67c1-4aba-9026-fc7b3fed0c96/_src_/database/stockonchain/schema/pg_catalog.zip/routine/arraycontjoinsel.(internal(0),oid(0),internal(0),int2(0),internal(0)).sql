create function arraycontjoinsel(internal, oid, internal, smallint, internal) returns double precision
LANGUAGE INTERNAL
AS $$
arraycontjoinsel
$$;
