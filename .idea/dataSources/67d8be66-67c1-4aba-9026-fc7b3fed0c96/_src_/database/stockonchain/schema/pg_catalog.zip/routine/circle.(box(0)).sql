create function circle(box) returns circle
LANGUAGE INTERNAL
AS $$
box_circle
$$;
