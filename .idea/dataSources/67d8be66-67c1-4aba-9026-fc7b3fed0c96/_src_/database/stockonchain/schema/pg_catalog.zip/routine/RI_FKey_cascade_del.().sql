create function "RI_FKey_cascade_del"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_cascade_del
$$;
