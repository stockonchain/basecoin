create function array_prepend(anyelement, anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_prepend
$$;
