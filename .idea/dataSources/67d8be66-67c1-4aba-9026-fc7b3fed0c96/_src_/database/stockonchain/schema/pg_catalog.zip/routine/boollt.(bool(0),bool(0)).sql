create function boollt(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boollt
$$;
