create function charge("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
charge
$$;
