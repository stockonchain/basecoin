create function btrecordcmp(record, record) returns integer
LANGUAGE INTERNAL
AS $$
btrecordcmp
$$;
