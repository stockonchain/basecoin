create function bound_box(box, box) returns box
LANGUAGE INTERNAL
AS $$
boxes_bound_box
$$;
