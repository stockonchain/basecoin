create function bpchar_larger(character, character) returns character
LANGUAGE INTERNAL
AS $$
bpchar_larger
$$;
