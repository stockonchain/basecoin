create function cash_cmp(money, money) returns integer
LANGUAGE INTERNAL
AS $$
cash_cmp
$$;
