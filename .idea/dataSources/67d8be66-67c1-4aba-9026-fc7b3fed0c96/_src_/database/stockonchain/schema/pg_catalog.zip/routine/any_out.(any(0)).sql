create function any_out("any") returns cstring
LANGUAGE INTERNAL
AS $$
any_out
$$;
