create function array_lt(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_lt
$$;
