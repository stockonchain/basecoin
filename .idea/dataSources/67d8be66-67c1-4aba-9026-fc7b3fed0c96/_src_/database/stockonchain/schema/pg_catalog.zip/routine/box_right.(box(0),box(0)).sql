create function box_right(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_right
$$;
