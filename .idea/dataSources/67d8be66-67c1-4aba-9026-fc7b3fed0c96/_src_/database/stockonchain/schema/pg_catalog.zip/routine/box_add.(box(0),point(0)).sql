create function box_add(box, point) returns box
LANGUAGE INTERNAL
AS $$
box_add
$$;
