create function close_sl(lseg, line) returns point
LANGUAGE INTERNAL
AS $$
close_sl
$$;
