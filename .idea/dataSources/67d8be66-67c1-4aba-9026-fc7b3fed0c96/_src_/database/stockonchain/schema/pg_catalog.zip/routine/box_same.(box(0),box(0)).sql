create function box_same(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_same
$$;
