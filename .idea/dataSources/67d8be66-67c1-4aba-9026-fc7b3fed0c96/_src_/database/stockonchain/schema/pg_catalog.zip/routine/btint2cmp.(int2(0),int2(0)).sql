create function btint2cmp(smallint, smallint) returns integer
LANGUAGE INTERNAL
AS $$
btint2cmp
$$;
