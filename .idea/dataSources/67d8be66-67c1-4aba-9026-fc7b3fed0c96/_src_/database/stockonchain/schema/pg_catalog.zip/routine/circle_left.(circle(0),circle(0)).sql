create function circle_left(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_left
$$;
