create function bpchar("char") returns character
LANGUAGE INTERNAL
AS $$
char_bpchar
$$;
