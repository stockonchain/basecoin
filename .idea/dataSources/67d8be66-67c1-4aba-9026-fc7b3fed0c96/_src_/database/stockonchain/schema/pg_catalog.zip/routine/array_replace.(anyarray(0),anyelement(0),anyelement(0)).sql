create function array_replace(anyarray, anyelement, anyelement) returns anyarray
LANGUAGE INTERNAL
AS $$
array_replace
$$;
