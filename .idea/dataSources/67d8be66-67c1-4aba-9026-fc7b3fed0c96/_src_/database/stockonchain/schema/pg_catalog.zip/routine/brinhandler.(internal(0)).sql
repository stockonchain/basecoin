create function brinhandler(internal) returns index_am_handler
LANGUAGE INTERNAL
AS $$
brinhandler
$$;
