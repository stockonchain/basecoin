create function array_send(anyarray) returns bytea
LANGUAGE INTERNAL
AS $$
array_send
$$;
