create function cosd(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dcosd
$$;
