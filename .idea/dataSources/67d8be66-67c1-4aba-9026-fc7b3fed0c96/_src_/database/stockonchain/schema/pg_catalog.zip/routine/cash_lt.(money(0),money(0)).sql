create function cash_lt(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_lt
$$;
