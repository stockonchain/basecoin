create function circle_contain_pt(circle, point) returns boolean
LANGUAGE INTERNAL
AS $$
circle_contain_pt
$$;
