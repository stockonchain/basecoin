create function bpcharrecv(internal, oid, integer) returns character
LANGUAGE INTERNAL
AS $$
bpcharrecv
$$;
