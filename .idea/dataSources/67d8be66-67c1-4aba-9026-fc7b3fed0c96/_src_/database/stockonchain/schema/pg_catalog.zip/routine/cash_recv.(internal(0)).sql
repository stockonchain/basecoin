create function cash_recv(internal) returns money
LANGUAGE INTERNAL
AS $$
cash_recv
$$;
