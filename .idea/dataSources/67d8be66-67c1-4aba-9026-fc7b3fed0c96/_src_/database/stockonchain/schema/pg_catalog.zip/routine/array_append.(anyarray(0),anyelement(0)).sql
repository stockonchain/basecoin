create function array_append(anyarray, anyelement) returns anyarray
LANGUAGE INTERNAL
AS $$
array_append
$$;
