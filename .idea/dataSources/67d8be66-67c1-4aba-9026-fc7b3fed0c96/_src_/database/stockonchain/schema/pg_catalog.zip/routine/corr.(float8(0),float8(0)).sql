create function corr(double precision, double precision) returns double precision
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
