create function btfloat4sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btfloat4sortsupport
$$;
