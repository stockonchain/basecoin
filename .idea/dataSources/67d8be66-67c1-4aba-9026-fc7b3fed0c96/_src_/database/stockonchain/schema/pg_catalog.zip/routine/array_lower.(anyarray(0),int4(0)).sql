create function array_lower(anyarray, integer) returns integer
LANGUAGE INTERNAL
AS $$
array_lower
$$;
