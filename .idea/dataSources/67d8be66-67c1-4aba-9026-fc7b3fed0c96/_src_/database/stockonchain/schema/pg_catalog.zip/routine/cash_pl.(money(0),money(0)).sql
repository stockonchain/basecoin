create function cash_pl(money, money) returns money
LANGUAGE INTERNAL
AS $$
cash_pl
$$;
