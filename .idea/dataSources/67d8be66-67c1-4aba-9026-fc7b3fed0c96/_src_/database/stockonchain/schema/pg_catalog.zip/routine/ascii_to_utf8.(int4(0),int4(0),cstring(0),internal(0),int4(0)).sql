create function ascii_to_utf8(integer, integer, cstring, internal, integer) returns void
LANGUAGE C
AS $$
ascii_to_utf8
$$;
