create function circle_overlap(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_overlap
$$;
