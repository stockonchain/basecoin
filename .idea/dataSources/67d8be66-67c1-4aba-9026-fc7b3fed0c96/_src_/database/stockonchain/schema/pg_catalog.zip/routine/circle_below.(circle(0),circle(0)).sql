create function circle_below(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_below
$$;
