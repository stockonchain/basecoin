create function array_agg(anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
