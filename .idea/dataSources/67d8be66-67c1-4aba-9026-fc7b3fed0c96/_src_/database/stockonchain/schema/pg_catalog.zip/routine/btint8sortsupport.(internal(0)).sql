create function btint8sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btint8sortsupport
$$;
