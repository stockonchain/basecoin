create function array_remove(anyarray, anyelement) returns anyarray
LANGUAGE INTERNAL
AS $$
array_remove
$$;
