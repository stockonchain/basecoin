create function cashsmaller(money, money) returns money
LANGUAGE INTERNAL
AS $$
cashsmaller
$$;
