create function bool(integer) returns boolean
LANGUAGE INTERNAL
AS $$
int4_bool
$$;
