create function cash_le(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_le
$$;
