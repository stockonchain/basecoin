create function cidr(inet) returns cidr
LANGUAGE INTERNAL
AS $$
inet_to_cidr
$$;
