create function arraycontained(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
arraycontained
$$;
