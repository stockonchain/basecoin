create function btrecordimagecmp(record, record) returns integer
LANGUAGE INTERNAL
AS $$
btrecordimagecmp
$$;
