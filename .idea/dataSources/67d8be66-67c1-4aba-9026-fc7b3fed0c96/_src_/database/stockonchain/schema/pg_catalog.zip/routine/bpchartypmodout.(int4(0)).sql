create function bpchartypmodout(integer) returns cstring
LANGUAGE INTERNAL
AS $$
bpchartypmodout
$$;
