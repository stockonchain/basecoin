create function aclinsert(aclitem[], aclitem) returns aclitem[]
LANGUAGE INTERNAL
AS $$
aclinsert
$$;
