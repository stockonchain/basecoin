create function circle_overleft(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_overleft
$$;
