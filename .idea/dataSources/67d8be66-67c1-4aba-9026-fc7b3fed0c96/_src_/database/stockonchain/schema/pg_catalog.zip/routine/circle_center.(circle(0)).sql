create function circle_center(circle) returns point
LANGUAGE INTERNAL
AS $$
circle_center
$$;
