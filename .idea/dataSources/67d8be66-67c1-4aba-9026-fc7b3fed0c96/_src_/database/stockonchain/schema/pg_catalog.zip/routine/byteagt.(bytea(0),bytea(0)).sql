create function byteagt(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteagt
$$;
