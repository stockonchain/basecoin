create function amvalidate(oid) returns boolean
LANGUAGE INTERNAL
AS $$
amvalidate
$$;
