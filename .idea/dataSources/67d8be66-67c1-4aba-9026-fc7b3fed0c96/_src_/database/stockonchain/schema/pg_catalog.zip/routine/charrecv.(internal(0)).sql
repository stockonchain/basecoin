create function charrecv(internal) returns "char"
LANGUAGE INTERNAL
AS $$
charrecv
$$;
