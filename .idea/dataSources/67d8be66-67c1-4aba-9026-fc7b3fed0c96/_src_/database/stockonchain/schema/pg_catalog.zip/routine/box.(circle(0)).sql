create function box(point, point) returns box
LANGUAGE INTERNAL
AS $$
points_box
$$;
