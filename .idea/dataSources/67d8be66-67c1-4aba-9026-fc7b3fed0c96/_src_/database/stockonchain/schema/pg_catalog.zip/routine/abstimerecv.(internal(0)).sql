create function abstimerecv(internal) returns abstime
LANGUAGE INTERNAL
AS $$
abstimerecv
$$;
