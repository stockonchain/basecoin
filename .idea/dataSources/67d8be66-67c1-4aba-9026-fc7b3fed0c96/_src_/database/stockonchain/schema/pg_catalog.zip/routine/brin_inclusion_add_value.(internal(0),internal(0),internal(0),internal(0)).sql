create function brin_inclusion_add_value(internal, internal, internal, internal) returns boolean
LANGUAGE INTERNAL
AS $$
brin_inclusion_add_value
$$;
