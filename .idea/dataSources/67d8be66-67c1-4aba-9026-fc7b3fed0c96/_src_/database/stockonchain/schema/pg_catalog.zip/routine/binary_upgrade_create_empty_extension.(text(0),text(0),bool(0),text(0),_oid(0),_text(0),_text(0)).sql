create function binary_upgrade_create_empty_extension(text, text, boolean, text, oid[], text[], text[]) returns void
LANGUAGE INTERNAL
AS $$
binary_upgrade_create_empty_extension
$$;
