create function box_overabove(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_overabove
$$;
