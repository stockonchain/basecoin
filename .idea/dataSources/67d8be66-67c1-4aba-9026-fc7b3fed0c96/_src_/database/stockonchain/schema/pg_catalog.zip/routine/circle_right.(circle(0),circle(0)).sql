create function circle_right(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_right
$$;
