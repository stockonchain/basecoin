create function bpchareq(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpchareq
$$;
