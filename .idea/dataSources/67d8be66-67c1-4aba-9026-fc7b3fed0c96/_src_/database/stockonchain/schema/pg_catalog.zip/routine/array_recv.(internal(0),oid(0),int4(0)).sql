create function array_recv(internal, oid, integer) returns anyarray
LANGUAGE INTERNAL
AS $$
array_recv
$$;
