create function binary_upgrade_set_record_init_privs(boolean) returns void
LANGUAGE INTERNAL
AS $$
binary_upgrade_set_record_init_privs
$$;
