create function bpchargt(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpchargt
$$;
