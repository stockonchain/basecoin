create function anyenum_in(cstring) returns anyenum
LANGUAGE INTERNAL
AS $$
anyenum_in
$$;
