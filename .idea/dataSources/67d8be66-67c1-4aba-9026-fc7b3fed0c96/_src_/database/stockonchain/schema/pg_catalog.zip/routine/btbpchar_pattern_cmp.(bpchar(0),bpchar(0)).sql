create function btbpchar_pattern_cmp(character, character) returns integer
LANGUAGE INTERNAL
AS $$
btbpchar_pattern_cmp
$$;
