create function cidr_send(cidr) returns bytea
LANGUAGE INTERNAL
AS $$
cidr_send
$$;
