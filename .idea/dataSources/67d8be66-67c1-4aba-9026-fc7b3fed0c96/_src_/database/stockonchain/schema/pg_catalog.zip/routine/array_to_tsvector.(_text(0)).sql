create function array_to_tsvector(text[]) returns tsvector
LANGUAGE INTERNAL
AS $$
array_to_tsvector
$$;
