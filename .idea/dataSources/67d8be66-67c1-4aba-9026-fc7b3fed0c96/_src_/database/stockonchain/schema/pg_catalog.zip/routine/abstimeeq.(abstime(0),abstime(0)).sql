create function abstimeeq(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimeeq
$$;
