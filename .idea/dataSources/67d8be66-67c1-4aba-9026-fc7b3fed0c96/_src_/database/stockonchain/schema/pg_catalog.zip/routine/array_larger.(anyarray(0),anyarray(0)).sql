create function array_larger(anyarray, anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_larger
$$;
