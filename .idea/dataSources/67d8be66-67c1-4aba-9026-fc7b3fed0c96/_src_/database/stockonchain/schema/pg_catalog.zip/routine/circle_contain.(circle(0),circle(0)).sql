create function circle_contain(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_contain
$$;
