create function bitor(bit, bit) returns bit
LANGUAGE INTERNAL
AS $$
bit_or
$$;
