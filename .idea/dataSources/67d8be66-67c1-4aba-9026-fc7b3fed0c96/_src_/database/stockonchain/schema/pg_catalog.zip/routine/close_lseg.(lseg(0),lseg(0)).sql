create function close_lseg(lseg, lseg) returns point
LANGUAGE INTERNAL
AS $$
close_lseg
$$;
