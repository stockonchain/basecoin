create function bit_or(smallint) returns smallint
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
