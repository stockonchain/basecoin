create function bit_out(bit) returns cstring
LANGUAGE INTERNAL
AS $$
bit_out
$$;
