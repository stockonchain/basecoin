create function bpcharsend(character) returns bytea
LANGUAGE INTERNAL
AS $$
bpcharsend
$$;
