create function cidin(cstring) returns cid
LANGUAGE INTERNAL
AS $$
cidin
$$;
