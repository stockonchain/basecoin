create function broadcast(inet) returns inet
LANGUAGE INTERNAL
AS $$
network_broadcast
$$;
