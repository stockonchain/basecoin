create function brin_inclusion_union(internal, internal, internal) returns boolean
LANGUAGE INTERNAL
AS $$
brin_inclusion_union
$$;
