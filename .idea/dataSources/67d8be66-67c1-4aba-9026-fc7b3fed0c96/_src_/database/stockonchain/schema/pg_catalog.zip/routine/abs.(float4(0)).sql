create function abs(real) returns real
LANGUAGE INTERNAL
AS $$
float4abs
$$;
