create function area(path) returns double precision
LANGUAGE INTERNAL
AS $$
path_area
$$;
