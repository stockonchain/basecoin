create function circle_sub_pt(circle, point) returns circle
LANGUAGE INTERNAL
AS $$
circle_sub_pt
$$;
