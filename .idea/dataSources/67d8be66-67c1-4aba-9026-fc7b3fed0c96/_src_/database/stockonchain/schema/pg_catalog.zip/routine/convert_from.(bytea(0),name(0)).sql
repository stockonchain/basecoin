create function convert_from(bytea, name) returns text
LANGUAGE INTERNAL
AS $$
pg_convert_from
$$;
