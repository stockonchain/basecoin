create function bpcharregexne(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
textregexne
$$;
