create function box_center(box) returns point
LANGUAGE INTERNAL
AS $$
box_center
$$;
