create function concat(VARIADIC "any") returns text
LANGUAGE INTERNAL
AS $$
text_concat
$$;
