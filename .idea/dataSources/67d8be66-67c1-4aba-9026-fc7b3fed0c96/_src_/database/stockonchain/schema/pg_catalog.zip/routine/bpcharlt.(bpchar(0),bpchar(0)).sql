create function bpcharlt(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpcharlt
$$;
