create function btoidvectorcmp(oidvector, oidvector) returns integer
LANGUAGE INTERNAL
AS $$
btoidvectorcmp
$$;
