create function byteale(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
byteale
$$;
