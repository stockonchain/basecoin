create function cot(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dcot
$$;
