create function anyarray_send(anyarray) returns bytea
LANGUAGE INTERNAL
AS $$
anyarray_send
$$;
