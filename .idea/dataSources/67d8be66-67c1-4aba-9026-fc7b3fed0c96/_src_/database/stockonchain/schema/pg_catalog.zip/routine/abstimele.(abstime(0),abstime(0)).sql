create function abstimele(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimele
$$;
