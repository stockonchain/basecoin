create function array_upper(anyarray, integer) returns integer
LANGUAGE INTERNAL
AS $$
array_upper
$$;
