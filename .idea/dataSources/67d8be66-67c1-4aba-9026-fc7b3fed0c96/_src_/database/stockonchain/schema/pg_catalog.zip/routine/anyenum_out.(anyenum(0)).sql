create function anyenum_out(anyenum) returns cstring
LANGUAGE INTERNAL
AS $$
anyenum_out
$$;
