create function array_ndims(anyarray) returns integer
LANGUAGE INTERNAL
AS $$
array_ndims
$$;
