create function anynonarray_in(cstring) returns anynonarray
LANGUAGE INTERNAL
AS $$
anynonarray_in
$$;
