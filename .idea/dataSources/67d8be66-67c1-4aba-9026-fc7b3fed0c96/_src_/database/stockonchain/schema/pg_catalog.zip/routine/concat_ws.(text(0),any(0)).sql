create function concat_ws(text, VARIADIC "any") returns text
LANGUAGE INTERNAL
AS $$
text_concat_ws
$$;
