create function close_lb(line, box) returns point
LANGUAGE INTERNAL
AS $$
close_lb
$$;
