create function cash_ne(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_ne
$$;
