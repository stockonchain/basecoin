create function box_mul(box, point) returns box
LANGUAGE INTERNAL
AS $$
box_mul
$$;
