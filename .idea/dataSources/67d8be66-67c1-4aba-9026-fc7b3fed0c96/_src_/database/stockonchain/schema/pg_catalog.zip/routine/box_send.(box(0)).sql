create function box_send(box) returns bytea
LANGUAGE INTERNAL
AS $$
box_send
$$;
