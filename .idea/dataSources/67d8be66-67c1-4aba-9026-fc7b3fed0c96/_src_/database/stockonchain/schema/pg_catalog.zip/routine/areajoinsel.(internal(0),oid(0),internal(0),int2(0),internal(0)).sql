create function areajoinsel(internal, oid, internal, smallint, internal) returns double precision
LANGUAGE INTERNAL
AS $$
areajoinsel
$$;
