create function bpcharlike(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
textlike
$$;
