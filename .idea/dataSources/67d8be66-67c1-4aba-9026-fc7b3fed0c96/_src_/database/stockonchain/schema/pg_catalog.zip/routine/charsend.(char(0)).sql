create function charsend("char") returns bytea
LANGUAGE INTERNAL
AS $$
charsend
$$;
