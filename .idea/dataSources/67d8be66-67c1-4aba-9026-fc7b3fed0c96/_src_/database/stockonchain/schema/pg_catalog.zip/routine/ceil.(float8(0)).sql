create function ceil(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dceil
$$;
