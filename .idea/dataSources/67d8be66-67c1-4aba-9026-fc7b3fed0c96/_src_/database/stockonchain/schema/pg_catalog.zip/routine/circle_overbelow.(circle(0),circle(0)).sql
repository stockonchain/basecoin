create function circle_overbelow(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_overbelow
$$;
