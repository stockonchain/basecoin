create function contsel(internal, oid, internal, integer) returns double precision
LANGUAGE INTERNAL
AS $$
contsel
$$;
