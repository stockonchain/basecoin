create function cash_send(money) returns bytea
LANGUAGE INTERNAL
AS $$
cash_send
$$;
