create function anyrange_out(anyrange) returns cstring
LANGUAGE INTERNAL
AS $$
anyrange_out
$$;
