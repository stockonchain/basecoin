create function array_ne(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_ne
$$;
