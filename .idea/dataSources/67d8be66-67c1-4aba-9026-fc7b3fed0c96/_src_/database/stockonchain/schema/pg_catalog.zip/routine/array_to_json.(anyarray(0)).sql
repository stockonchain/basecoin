create function array_to_json(anyarray) returns json
LANGUAGE INTERNAL
AS $$
array_to_json
$$;
