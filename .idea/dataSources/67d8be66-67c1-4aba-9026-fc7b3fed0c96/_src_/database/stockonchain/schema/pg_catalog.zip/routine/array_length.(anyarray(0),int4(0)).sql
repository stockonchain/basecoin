create function array_length(anyarray, integer) returns integer
LANGUAGE INTERNAL
AS $$
array_length
$$;
