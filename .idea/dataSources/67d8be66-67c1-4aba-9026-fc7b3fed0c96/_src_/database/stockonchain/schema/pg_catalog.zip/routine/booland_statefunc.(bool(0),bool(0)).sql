create function booland_statefunc(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
booland_statefunc
$$;
