create function byteaout(bytea) returns cstring
LANGUAGE INTERNAL
AS $$
byteaout
$$;
