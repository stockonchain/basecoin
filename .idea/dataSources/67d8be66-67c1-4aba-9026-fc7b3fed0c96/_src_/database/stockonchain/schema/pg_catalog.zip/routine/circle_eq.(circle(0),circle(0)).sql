create function circle_eq(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_eq
$$;
