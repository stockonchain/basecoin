create function close_pl(point, line) returns point
LANGUAGE INTERNAL
AS $$
close_pl
$$;
