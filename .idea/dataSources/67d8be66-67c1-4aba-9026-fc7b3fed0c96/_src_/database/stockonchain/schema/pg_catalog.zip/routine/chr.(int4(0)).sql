create function chr(integer) returns text
LANGUAGE INTERNAL
AS $$
chr
$$;
