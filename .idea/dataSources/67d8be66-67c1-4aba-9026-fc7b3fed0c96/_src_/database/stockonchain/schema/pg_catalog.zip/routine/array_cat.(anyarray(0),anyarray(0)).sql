create function array_cat(anyarray, anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_cat
$$;
