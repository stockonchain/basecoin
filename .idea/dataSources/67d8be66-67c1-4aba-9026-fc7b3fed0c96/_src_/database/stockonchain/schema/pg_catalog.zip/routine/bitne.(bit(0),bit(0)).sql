create function bitne(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
bitne
$$;
