create function bpcharge(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpcharge
$$;
