create function abstimegt(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimegt
$$;
