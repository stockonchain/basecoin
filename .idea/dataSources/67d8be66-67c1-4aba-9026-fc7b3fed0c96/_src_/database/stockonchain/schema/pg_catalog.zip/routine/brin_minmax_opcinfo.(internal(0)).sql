create function brin_minmax_opcinfo(internal) returns internal
LANGUAGE INTERNAL
AS $$
brin_minmax_opcinfo
$$;
