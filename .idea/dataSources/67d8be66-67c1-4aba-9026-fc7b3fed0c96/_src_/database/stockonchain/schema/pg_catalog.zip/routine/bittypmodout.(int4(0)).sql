create function bittypmodout(integer) returns cstring
LANGUAGE INTERNAL
AS $$
bittypmodout
$$;
