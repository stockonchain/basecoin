create function bitge(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
bitge
$$;
