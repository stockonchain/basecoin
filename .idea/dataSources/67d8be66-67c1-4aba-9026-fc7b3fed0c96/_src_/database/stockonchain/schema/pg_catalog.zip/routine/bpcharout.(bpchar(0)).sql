create function bpcharout(character) returns cstring
LANGUAGE INTERNAL
AS $$
bpcharout
$$;
