create function array_to_string(anyarray, text) returns text
LANGUAGE INTERNAL
AS $$
array_to_text
$$;
