create function binary_upgrade_set_next_pg_enum_oid(oid) returns void
LANGUAGE INTERNAL
AS $$
binary_upgrade_set_next_pg_enum_oid
$$;
