create function anyrange_in(cstring, oid, integer) returns anyrange
LANGUAGE INTERNAL
AS $$
anyrange_in
$$;
