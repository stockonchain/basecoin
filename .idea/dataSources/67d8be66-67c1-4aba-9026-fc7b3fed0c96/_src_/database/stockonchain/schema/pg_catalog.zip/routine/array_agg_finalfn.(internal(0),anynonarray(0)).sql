create function array_agg_finalfn(internal, anynonarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_agg_finalfn
$$;
