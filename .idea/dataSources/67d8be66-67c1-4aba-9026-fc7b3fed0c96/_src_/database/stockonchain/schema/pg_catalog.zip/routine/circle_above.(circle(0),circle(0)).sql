create function circle_above(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_above
$$;
