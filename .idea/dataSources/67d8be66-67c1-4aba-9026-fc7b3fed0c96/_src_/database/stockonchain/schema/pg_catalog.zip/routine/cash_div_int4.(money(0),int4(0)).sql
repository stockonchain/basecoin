create function cash_div_int4(money, integer) returns money
LANGUAGE INTERNAL
AS $$
cash_div_int4
$$;
