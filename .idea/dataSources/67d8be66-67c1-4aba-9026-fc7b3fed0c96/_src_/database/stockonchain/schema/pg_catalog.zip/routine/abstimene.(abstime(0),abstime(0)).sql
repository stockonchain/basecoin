create function abstimene(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimene
$$;
