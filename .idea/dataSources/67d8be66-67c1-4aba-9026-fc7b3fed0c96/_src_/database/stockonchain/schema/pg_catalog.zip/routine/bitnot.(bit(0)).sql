create function bitnot(bit) returns bit
LANGUAGE INTERNAL
AS $$
bitnot
$$;
