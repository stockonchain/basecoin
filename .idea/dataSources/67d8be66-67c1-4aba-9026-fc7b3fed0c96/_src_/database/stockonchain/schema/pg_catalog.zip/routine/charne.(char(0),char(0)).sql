create function charne("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
charne
$$;
