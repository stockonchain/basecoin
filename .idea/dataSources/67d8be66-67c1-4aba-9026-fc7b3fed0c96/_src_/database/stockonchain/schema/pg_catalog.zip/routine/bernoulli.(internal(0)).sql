create function bernoulli(internal) returns tsm_handler
LANGUAGE INTERNAL
AS $$
tsm_bernoulli_handler
$$;
