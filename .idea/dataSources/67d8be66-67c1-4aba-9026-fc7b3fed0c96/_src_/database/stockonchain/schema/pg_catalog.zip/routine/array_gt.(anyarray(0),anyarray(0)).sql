create function array_gt(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
array_gt
$$;
