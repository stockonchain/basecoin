create function arrayoverlap(anyarray, anyarray) returns boolean
LANGUAGE INTERNAL
AS $$
arrayoverlap
$$;
