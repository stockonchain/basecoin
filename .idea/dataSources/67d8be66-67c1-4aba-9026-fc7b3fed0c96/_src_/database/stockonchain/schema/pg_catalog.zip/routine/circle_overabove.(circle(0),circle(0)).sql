create function circle_overabove(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_overabove
$$;
