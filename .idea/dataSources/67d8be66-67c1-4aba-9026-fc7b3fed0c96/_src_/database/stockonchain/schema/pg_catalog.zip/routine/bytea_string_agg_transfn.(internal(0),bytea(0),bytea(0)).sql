create function bytea_string_agg_transfn(internal, bytea, bytea) returns internal
LANGUAGE INTERNAL
AS $$
bytea_string_agg_transfn
$$;
