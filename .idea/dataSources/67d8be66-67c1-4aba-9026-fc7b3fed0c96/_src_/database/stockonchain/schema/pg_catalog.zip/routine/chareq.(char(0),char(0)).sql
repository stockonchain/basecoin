create function chareq("char", "char") returns boolean
LANGUAGE INTERNAL
AS $$
chareq
$$;
