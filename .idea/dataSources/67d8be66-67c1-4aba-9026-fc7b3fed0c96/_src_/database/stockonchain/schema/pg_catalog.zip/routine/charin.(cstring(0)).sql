create function charin(cstring) returns "char"
LANGUAGE INTERNAL
AS $$
charin
$$;
