create function circle_out(circle) returns cstring
LANGUAGE INTERNAL
AS $$
circle_out
$$;
