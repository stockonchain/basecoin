create function box_above_eq(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_above_eq
$$;
