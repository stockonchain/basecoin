create function aclexplode(acl aclitem[], OUT grantor oid, OUT grantee oid, OUT privilege_type text, OUT is_grantable boolean) returns SETOF record
LANGUAGE INTERNAL
AS $$
aclexplode
$$;
