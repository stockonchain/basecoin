create function bit_and(smallint) returns smallint
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
