create function byteain(cstring) returns bytea
LANGUAGE INTERNAL
AS $$
byteain
$$;
