create function "RI_FKey_setnull_del"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_setnull_del
$$;
