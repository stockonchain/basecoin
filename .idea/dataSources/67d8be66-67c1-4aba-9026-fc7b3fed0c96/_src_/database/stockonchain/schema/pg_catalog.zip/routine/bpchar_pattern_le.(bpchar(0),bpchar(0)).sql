create function bpchar_pattern_le(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpchar_pattern_le
$$;
