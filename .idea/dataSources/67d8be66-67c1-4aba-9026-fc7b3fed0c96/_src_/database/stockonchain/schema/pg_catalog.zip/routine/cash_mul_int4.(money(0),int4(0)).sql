create function cash_mul_int4(money, integer) returns money
LANGUAGE INTERNAL
AS $$
cash_mul_int4
$$;
