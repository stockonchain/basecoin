create function bpchariclike(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
texticlike
$$;
