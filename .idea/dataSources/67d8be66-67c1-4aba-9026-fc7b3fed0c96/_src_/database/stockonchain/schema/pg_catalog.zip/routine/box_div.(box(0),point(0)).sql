create function box_div(box, point) returns box
LANGUAGE INTERNAL
AS $$
box_div
$$;
