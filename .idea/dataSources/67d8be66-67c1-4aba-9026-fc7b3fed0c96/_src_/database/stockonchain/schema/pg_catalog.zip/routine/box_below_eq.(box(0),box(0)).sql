create function box_below_eq(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_below_eq
$$;
