create function box_intersect(box, box) returns box
LANGUAGE INTERNAL
AS $$
box_intersect
$$;
