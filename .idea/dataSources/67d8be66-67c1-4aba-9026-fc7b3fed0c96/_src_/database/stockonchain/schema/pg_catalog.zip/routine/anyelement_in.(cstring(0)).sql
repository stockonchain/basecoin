create function anyelement_in(cstring) returns anyelement
LANGUAGE INTERNAL
AS $$
anyelement_in
$$;
