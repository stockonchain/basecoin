create function circle_ne(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_ne
$$;
