create function bpchar_pattern_gt(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpchar_pattern_gt
$$;
