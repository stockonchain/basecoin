create function asind(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dasind
$$;
