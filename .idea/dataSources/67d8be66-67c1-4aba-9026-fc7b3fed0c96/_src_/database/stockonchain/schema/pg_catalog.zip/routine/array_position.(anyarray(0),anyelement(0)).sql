create function array_position(anyarray, anyelement) returns integer
LANGUAGE INTERNAL
AS $$
array_position
$$;
