create function cidout(cid) returns cstring
LANGUAGE INTERNAL
AS $$
cidout
$$;
