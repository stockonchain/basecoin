create function cash_mul_flt4(money, real) returns money
LANGUAGE INTERNAL
AS $$
cash_mul_flt4
$$;
