create function aclitemeq(aclitem, aclitem) returns boolean
LANGUAGE INTERNAL
AS $$
aclitem_eq
$$;
