create function byteacat(bytea, bytea) returns bytea
LANGUAGE INTERNAL
AS $$
byteacat
$$;
