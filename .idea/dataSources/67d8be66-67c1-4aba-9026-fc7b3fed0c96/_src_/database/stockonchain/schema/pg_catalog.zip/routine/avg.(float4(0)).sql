create function avg(bigint) returns numeric
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
