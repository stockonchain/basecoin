create function boolge(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boolge
$$;
