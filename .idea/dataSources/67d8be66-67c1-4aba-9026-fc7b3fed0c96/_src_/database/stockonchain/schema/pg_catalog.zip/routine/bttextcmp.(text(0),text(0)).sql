create function bttextcmp(text, text) returns integer
LANGUAGE INTERNAL
AS $$
bttextcmp
$$;
