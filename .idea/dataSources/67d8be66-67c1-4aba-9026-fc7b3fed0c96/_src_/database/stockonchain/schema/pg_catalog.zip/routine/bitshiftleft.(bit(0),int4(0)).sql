create function bitshiftleft(bit, integer) returns bit
LANGUAGE INTERNAL
AS $$
bitshiftleft
$$;
