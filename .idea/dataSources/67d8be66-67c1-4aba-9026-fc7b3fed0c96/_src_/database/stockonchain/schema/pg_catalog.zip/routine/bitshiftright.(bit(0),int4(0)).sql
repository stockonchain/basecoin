create function bitshiftright(bit, integer) returns bit
LANGUAGE INTERNAL
AS $$
bitshiftright
$$;
