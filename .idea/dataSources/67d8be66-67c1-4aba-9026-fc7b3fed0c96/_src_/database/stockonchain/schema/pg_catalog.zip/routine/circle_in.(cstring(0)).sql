create function circle_in(cstring) returns circle
LANGUAGE INTERNAL
AS $$
circle_in
$$;
