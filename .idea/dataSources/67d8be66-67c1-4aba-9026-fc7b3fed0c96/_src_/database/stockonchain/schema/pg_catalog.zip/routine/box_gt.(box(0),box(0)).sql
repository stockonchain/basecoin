create function box_gt(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_gt
$$;
