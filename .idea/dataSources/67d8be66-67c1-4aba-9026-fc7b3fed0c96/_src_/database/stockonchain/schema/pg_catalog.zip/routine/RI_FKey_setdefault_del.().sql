create function "RI_FKey_setdefault_del"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_setdefault_del
$$;
