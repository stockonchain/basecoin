create function anyarray_out(anyarray) returns cstring
LANGUAGE INTERNAL
AS $$
anyarray_out
$$;
