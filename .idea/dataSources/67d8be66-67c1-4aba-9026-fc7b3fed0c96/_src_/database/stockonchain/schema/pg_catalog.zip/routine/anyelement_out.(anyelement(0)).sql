create function anyelement_out(anyelement) returns cstring
LANGUAGE INTERNAL
AS $$
anyelement_out
$$;
