create function cidrecv(internal) returns cid
LANGUAGE INTERNAL
AS $$
cidrecv
$$;
