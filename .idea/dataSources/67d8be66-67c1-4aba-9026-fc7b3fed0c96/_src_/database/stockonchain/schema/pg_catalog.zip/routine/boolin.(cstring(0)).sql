create function boolin(cstring) returns boolean
LANGUAGE INTERNAL
AS $$
boolin
$$;
