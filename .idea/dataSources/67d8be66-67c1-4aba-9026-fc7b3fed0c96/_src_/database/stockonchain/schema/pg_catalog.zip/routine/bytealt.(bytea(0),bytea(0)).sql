create function bytealt(bytea, bytea) returns boolean
LANGUAGE INTERNAL
AS $$
bytealt
$$;
