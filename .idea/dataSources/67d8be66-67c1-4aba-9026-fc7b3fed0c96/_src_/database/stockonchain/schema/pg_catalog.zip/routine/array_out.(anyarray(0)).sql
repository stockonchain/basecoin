create function array_out(anyarray) returns cstring
LANGUAGE INTERNAL
AS $$
array_out
$$;
