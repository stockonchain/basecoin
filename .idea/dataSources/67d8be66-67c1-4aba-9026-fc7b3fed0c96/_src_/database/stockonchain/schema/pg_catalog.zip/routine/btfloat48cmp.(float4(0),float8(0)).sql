create function btfloat48cmp(real, double precision) returns integer
LANGUAGE INTERNAL
AS $$
btfloat48cmp
$$;
