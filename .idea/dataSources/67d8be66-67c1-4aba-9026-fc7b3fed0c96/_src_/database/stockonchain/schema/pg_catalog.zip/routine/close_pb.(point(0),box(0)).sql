create function close_pb(point, box) returns point
LANGUAGE INTERNAL
AS $$
close_pb
$$;
