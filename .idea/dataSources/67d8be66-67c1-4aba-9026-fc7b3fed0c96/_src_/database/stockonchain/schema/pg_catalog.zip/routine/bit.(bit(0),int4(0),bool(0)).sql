create function bit(bigint, integer) returns bit
LANGUAGE INTERNAL
AS $$
bitfromint8
$$;
