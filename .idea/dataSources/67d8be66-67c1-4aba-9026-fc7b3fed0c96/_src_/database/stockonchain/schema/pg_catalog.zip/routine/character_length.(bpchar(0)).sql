create function character_length(text) returns integer
LANGUAGE INTERNAL
AS $$
textlen
$$;
