create function contjoinsel(internal, oid, internal, smallint, internal) returns double precision
LANGUAGE INTERNAL
AS $$
contjoinsel
$$;
