create function bool_accum_inv(internal, boolean) returns internal
LANGUAGE INTERNAL
AS $$
bool_accum_inv
$$;
