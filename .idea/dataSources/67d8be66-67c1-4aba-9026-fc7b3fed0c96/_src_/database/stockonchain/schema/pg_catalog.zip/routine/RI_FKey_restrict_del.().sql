create function "RI_FKey_restrict_del"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_restrict_del
$$;
