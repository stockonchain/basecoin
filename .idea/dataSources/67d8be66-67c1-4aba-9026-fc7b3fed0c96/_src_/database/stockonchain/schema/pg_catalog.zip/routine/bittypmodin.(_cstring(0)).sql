create function bittypmodin(cstring[]) returns integer
LANGUAGE INTERNAL
AS $$
bittypmodin
$$;
