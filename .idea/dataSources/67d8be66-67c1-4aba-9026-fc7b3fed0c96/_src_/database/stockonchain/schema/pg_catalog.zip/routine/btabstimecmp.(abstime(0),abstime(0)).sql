create function btabstimecmp(abstime, abstime) returns integer
LANGUAGE INTERNAL
AS $$
btabstimecmp
$$;
