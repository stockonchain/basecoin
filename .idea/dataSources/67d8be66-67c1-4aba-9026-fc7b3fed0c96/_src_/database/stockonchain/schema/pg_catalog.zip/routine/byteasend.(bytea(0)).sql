create function byteasend(bytea) returns bytea
LANGUAGE INTERNAL
AS $$
byteasend
$$;
