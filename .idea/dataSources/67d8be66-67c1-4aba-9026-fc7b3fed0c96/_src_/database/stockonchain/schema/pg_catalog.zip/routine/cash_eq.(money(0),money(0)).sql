create function cash_eq(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_eq
$$;
