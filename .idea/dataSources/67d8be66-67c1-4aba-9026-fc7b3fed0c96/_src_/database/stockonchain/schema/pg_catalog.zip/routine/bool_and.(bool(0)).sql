create function bool_and(boolean) returns boolean
LANGUAGE INTERNAL
AS $$
aggregate_dummy
$$;
