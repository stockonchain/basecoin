create function bpcharcmp(character, character) returns integer
LANGUAGE INTERNAL
AS $$
bpcharcmp
$$;
