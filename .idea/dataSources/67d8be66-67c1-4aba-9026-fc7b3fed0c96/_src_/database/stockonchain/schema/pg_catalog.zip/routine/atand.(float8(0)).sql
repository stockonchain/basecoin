create function atand(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
datand
$$;
