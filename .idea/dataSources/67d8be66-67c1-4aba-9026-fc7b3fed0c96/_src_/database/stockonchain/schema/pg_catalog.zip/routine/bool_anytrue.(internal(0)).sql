create function bool_anytrue(internal) returns boolean
LANGUAGE INTERNAL
AS $$
bool_anytrue
$$;
