create function any_in(cstring) returns "any"
LANGUAGE INTERNAL
AS $$
any_in
$$;
