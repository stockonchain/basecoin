create function bitand(bit, bit) returns bit
LANGUAGE INTERNAL
AS $$
bit_and
$$;
