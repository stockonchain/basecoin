create function brin_minmax_union(internal, internal, internal) returns boolean
LANGUAGE INTERNAL
AS $$
brin_minmax_union
$$;
