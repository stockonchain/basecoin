create function bttext_pattern_sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
bttext_pattern_sortsupport
$$;
