create function array_typanalyze(internal) returns boolean
LANGUAGE INTERNAL
AS $$
array_typanalyze
$$;
