create function bttidcmp(tid, tid) returns integer
LANGUAGE INTERNAL
AS $$
bttidcmp
$$;
