create function box_contain(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_contain
$$;
