create function cash_div_flt8(money, double precision) returns money
LANGUAGE INTERNAL
AS $$
cash_div_flt8
$$;
