create function btint2sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btint2sortsupport
$$;
