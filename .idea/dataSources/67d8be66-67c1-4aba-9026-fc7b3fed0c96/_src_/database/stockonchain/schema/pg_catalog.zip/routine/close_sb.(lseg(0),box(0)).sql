create function close_sb(lseg, box) returns point
LANGUAGE INTERNAL
AS $$
close_sb
$$;
