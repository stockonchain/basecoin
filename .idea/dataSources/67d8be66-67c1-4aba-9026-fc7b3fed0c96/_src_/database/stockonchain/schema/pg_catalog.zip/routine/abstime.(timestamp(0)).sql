create function abstime(timestamp without time zone) returns abstime
LANGUAGE INTERNAL
AS $$
timestamp_abstime
$$;
