create function cash_div_flt4(money, real) returns money
LANGUAGE INTERNAL
AS $$
cash_div_flt4
$$;
