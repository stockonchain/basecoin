create function brin_inclusion_opcinfo(internal) returns internal
LANGUAGE INTERNAL
AS $$
brin_inclusion_opcinfo
$$;
