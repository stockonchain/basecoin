create function acos(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dacos
$$;
