create function box_below(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_below
$$;
