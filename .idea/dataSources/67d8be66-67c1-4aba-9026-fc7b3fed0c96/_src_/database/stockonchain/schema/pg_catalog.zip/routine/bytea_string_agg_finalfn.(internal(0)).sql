create function bytea_string_agg_finalfn(internal) returns bytea
LANGUAGE INTERNAL
AS $$
bytea_string_agg_finalfn
$$;
