create function bytearecv(internal) returns bytea
LANGUAGE INTERNAL
AS $$
bytearecv
$$;
