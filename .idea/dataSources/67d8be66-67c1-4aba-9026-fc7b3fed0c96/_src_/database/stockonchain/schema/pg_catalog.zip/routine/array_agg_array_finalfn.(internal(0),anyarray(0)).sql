create function array_agg_array_finalfn(internal, anyarray) returns anyarray
LANGUAGE INTERNAL
AS $$
array_agg_array_finalfn
$$;
