create function box_recv(internal) returns box
LANGUAGE INTERNAL
AS $$
box_recv
$$;
