create function btfloat8cmp(double precision, double precision) returns integer
LANGUAGE INTERNAL
AS $$
btfloat8cmp
$$;
