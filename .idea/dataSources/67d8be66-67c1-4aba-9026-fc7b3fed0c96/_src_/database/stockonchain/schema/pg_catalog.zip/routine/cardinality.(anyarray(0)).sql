create function cardinality(anyarray) returns integer
LANGUAGE INTERNAL
AS $$
array_cardinality
$$;
