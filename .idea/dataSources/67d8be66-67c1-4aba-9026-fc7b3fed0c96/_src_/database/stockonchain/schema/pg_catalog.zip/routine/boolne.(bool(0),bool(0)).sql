create function boolne(boolean, boolean) returns boolean
LANGUAGE INTERNAL
AS $$
boolne
$$;
