create function center(box) returns point
LANGUAGE INTERNAL
AS $$
box_center
$$;
