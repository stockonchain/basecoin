create function btint82cmp(bigint, smallint) returns integer
LANGUAGE INTERNAL
AS $$
btint82cmp
$$;
