create function btoidsortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btoidsortsupport
$$;
