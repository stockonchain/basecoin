create function bitle(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
bitle
$$;
