create function box_overleft(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_overleft
$$;
