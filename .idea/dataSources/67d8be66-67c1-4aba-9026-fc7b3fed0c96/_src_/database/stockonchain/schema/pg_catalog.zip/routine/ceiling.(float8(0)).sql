create function ceiling(double precision) returns double precision
LANGUAGE INTERNAL
AS $$
dceil
$$;
