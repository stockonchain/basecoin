create function bitxor(bit, bit) returns bit
LANGUAGE INTERNAL
AS $$
bitxor
$$;
