create function brin_inclusion_consistent(internal, internal, internal) returns boolean
LANGUAGE INTERNAL
AS $$
brin_inclusion_consistent
$$;
