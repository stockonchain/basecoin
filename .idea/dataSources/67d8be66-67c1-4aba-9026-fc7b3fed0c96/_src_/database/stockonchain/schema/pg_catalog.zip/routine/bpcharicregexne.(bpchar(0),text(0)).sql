create function bpcharicregexne(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
texticregexne
$$;
