create function bytea_sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
bytea_sortsupport
$$;
