create function cash_out(money) returns cstring
LANGUAGE INTERNAL
AS $$
cash_out
$$;
