create function aclcontains(aclitem[], aclitem) returns boolean
LANGUAGE INTERNAL
AS $$
aclcontains
$$;
