create function charout("char") returns cstring
LANGUAGE INTERNAL
AS $$
charout
$$;
