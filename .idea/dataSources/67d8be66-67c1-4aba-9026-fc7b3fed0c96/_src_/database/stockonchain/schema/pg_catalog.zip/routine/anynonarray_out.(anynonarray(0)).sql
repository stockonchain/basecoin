create function anynonarray_out(anynonarray) returns cstring
LANGUAGE INTERNAL
AS $$
anynonarray_out
$$;
