create function btboolcmp(boolean, boolean) returns integer
LANGUAGE INTERNAL
AS $$
btboolcmp
$$;
