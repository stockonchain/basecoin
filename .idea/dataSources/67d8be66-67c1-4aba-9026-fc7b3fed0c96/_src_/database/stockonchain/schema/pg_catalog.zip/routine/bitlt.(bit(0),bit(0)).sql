create function bitlt(bit, bit) returns boolean
LANGUAGE INTERNAL
AS $$
bitlt
$$;
