create function circle_div_pt(circle, point) returns circle
LANGUAGE INTERNAL
AS $$
circle_div_pt
$$;
