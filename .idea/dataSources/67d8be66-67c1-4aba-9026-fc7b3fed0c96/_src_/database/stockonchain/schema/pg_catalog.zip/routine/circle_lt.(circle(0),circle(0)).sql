create function circle_lt(circle, circle) returns boolean
LANGUAGE INTERNAL
AS $$
circle_lt
$$;
