create function close_ps(point, lseg) returns point
LANGUAGE INTERNAL
AS $$
close_ps
$$;
