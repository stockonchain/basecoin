create function bpchar_smaller(character, character) returns character
LANGUAGE INTERNAL
AS $$
bpchar_smaller
$$;
