create function ascii(text) returns integer
LANGUAGE INTERNAL
AS $$
ascii
$$;
