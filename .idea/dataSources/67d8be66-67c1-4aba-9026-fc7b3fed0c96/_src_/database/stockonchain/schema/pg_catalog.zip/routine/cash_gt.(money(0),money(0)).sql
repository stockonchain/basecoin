create function cash_gt(money, money) returns boolean
LANGUAGE INTERNAL
AS $$
cash_gt
$$;
