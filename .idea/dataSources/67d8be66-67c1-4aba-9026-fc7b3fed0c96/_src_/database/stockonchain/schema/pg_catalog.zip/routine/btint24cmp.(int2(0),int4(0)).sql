create function btint24cmp(smallint, integer) returns integer
LANGUAGE INTERNAL
AS $$
btint24cmp
$$;
