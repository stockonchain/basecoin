create function btrim(text) returns text
LANGUAGE INTERNAL
AS $$
btrim1
$$;
