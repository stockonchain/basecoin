create function "RI_FKey_cascade_upd"() returns trigger
LANGUAGE INTERNAL
AS $$
RI_FKey_cascade_upd
$$;
