create function box_contain_pt(box, point) returns boolean
LANGUAGE INTERNAL
AS $$
box_contain_pt
$$;
