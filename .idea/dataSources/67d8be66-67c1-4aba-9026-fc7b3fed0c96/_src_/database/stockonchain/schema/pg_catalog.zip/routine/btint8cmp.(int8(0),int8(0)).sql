create function btint8cmp(bigint, bigint) returns integer
LANGUAGE INTERNAL
AS $$
btint8cmp
$$;
