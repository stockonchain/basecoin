create function box_in(cstring) returns box
LANGUAGE INTERNAL
AS $$
box_in
$$;
