create function bit_in(cstring, oid, integer) returns bit
LANGUAGE INTERNAL
AS $$
bit_in
$$;
