create function binary_upgrade_set_next_toast_pg_type_oid(oid) returns void
LANGUAGE INTERNAL
AS $$
binary_upgrade_set_next_toast_pg_type_oid
$$;
