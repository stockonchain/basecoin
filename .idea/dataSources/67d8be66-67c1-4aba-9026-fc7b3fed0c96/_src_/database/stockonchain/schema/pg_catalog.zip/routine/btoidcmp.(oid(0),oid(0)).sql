create function btoidcmp(oid, oid) returns integer
LANGUAGE INTERNAL
AS $$
btoidcmp
$$;
