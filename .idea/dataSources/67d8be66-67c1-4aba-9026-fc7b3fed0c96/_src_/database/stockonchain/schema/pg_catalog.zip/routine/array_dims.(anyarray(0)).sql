create function array_dims(anyarray) returns text
LANGUAGE INTERNAL
AS $$
array_dims
$$;
