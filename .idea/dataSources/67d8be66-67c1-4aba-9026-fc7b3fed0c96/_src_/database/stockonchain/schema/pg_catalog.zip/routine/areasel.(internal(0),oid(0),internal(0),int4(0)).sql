create function areasel(internal, oid, internal, integer) returns double precision
LANGUAGE INTERNAL
AS $$
areasel
$$;
