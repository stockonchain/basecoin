create function btfloat8sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btfloat8sortsupport
$$;
