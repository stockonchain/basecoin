create function box_left(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_left
$$;
