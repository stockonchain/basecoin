create function btint84cmp(bigint, integer) returns integer
LANGUAGE INTERNAL
AS $$
btint84cmp
$$;
