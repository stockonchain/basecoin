create function abstimege(abstime, abstime) returns boolean
LANGUAGE INTERNAL
AS $$
abstimege
$$;
