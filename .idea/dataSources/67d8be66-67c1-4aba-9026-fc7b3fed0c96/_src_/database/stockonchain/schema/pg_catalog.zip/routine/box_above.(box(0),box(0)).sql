create function box_above(box, box) returns boolean
LANGUAGE INTERNAL
AS $$
box_above
$$;
