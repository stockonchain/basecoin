create function cidsend(cid) returns bytea
LANGUAGE INTERNAL
AS $$
cidsend
$$;
