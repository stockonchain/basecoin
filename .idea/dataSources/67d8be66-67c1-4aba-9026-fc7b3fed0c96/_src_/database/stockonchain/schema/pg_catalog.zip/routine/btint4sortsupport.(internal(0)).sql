create function btint4sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btint4sortsupport
$$;
