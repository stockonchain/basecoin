create function close_ls(line, lseg) returns point
LANGUAGE INTERNAL
AS $$
close_ls
$$;
