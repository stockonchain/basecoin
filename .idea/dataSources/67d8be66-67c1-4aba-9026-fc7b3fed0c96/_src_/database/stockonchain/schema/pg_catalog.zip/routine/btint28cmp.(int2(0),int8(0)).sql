create function btint28cmp(smallint, bigint) returns integer
LANGUAGE INTERNAL
AS $$
btint28cmp
$$;
