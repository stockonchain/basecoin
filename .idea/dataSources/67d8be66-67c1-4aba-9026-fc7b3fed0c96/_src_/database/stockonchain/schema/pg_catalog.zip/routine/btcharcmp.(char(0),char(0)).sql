create function btcharcmp("char", "char") returns integer
LANGUAGE INTERNAL
AS $$
btcharcmp
$$;
