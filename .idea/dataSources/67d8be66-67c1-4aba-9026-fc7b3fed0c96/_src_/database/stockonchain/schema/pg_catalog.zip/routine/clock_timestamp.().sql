create function clock_timestamp() returns timestamp with time zone
LANGUAGE INTERNAL
AS $$
clock_timestamp
$$;
