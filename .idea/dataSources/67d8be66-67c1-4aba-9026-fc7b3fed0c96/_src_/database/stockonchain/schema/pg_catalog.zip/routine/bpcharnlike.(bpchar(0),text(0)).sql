create function bpcharnlike(character, text) returns boolean
LANGUAGE INTERNAL
AS $$
textnlike
$$;
