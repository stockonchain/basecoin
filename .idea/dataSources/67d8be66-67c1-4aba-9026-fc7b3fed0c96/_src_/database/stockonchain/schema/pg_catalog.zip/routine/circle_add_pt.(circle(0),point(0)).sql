create function circle_add_pt(circle, point) returns circle
LANGUAGE INTERNAL
AS $$
circle_add_pt
$$;
