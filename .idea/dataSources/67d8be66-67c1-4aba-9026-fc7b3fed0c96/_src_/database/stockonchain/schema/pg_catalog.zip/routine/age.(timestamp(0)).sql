create function age(xid) returns integer
LANGUAGE INTERNAL
AS $$
xid_age
$$;
