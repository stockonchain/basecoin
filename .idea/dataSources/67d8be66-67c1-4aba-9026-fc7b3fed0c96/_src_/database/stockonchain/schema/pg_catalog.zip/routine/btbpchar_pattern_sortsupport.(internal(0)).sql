create function btbpchar_pattern_sortsupport(internal) returns void
LANGUAGE INTERNAL
AS $$
btbpchar_pattern_sortsupport
$$;
