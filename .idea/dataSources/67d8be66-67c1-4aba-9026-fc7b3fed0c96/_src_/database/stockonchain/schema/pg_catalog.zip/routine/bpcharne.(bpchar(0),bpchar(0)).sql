create function bpcharne(character, character) returns boolean
LANGUAGE INTERNAL
AS $$
bpcharne
$$;
