create function atan2(double precision, double precision) returns double precision
LANGUAGE INTERNAL
AS $$
datan2
$$;
